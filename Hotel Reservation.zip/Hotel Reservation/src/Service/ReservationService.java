package Service;

import model.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Stream;

public final class ReservationService {


    private static Map<String,IRoom> roomStorage;
    private static Map<String,Reservation> reserveStorage;


    private ReservationService(){}

    public static void addRoom(String roomNo,Double roomPrice, RoomType roomType){
        IRoom room = new Room(roomNo,roomPrice,roomType);
        if(roomStorage == null){
            roomStorage = new HashMap<String,IRoom>();
        }
        if(roomStorage.containsValue(room)){
            System.out.println(room + " 'Already Exist' ");
        }else {
            roomStorage.put(room.getRoomNumber(),room);

        }
    }
    public static List<IRoom> getAllRooms(){
        if(!(roomStorage == null)){
            List<IRoom> allRooms = new ArrayList<IRoom>(roomStorage.values());
            return allRooms;
        }else {
            System.out.println("No room registered");
            return null;
        }

    }

    public static IRoom getARoom(String roomNumber){
        if(roomStorage.containsKey(roomNumber)) {
            return roomStorage.get(roomNumber);
        }else {
            System.out.println("Room " + roomNumber + " not available");
            return null;
        }
    }

    public static Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        Date presentDate = new Date();
        if(!(reserveStorage == null)) {
            try {
                for (Reservation reservation : reserveStorage.values()) {
                    if (presentDate.after(reservation.getCheckOutDate())) {
                        IRoom room1 = reservation.getRoom();
                        room1.setAvailable(true);
                        reserveStorage.remove(customer.getEmail(), reservation);
                    }
                }
            } catch (Exception e) {
            }
        }
        if(reserveStorage == null){
            reserveStorage = new HashMap<String,Reservation>();
        }
        if(room.isAvailable()){
            Reservation newReserve = new Reservation(customer,room,checkInDate,checkOutDate);
            reserveStorage.put(customer.getEmail(), newReserve);
            room.setAvailable(false);
            return newReserve;
        }else {

           System.out.println("Room requested for is not Available");
           return null;
        }

    }


    public static List<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        //Date presentDate = new Date();
        //Calendar calendar= Calendar.getInstance();
        //calendar.setTime(checkInDate);
        if(roomStorage == null){
            System.out.println("No room registered");
            return null;
        }

        Set<IRoom> nonAvail = new HashSet<IRoom>();
        Set<IRoom> allrooms = new HashSet<IRoom>(roomStorage.values());
        if(!(reserveStorage == null)) {
            for (Reservation reservation : reserveStorage.values()) {
                if (checkInDate.after(reservation.getCheckOutDate()) || checkOutDate.before(reservation.getCheckInDate())) {

                } else {
                    IRoom room = reservation.getRoom();
                    nonAvail.add(room);
                }
            }
        }

        try {
            allrooms.removeAll(nonAvail);
        }catch (UnsupportedOperationException e){
            e.getLocalizedMessage();
        }
        List<IRoom> availableRooms = new ArrayList<IRoom>(allrooms);
        return availableRooms;
    }

    public static List<Reservation> getCustomersReservation(Customer customer){
        if((reserveStorage.containsKey(customer.getEmail()))) {
            List<Reservation> CustomersReservation = new ArrayList<Reservation>();
            Reservation custReserve = reserveStorage.get(customer.getEmail());
            CustomersReservation.add(custReserve);
            return CustomersReservation;
        }else {
            System.out.println(customer + " doesn't exist");
            return null;
        }

    }

    public static void printAllReservation(){
        for(Reservation reservation: reserveStorage.values()) System.out.println("\n"+reservation);

    }




}

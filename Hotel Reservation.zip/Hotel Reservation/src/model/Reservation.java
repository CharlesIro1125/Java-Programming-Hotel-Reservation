package model;

import java.util.Date;

public class Reservation implements Comparable<Reservation>{
    private Customer customer;
    private IRoom room;
    private Date checkInDate;
    private Date checkOutDate;

    public Reservation(Customer customer,IRoom room,Date checkInDate,Date checkOutDate){
        this.customer = customer;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;

    }
    public IRoom getRoom(){
        return this.room;
    }

    public Customer getCustomer(){
        return this.customer;
    }

    public Date getCheckInDate(){
        return this.checkInDate;
    }
    public Date getCheckOutDate(){
        return this.checkOutDate;
    }

    public String toString(){
        return this.customer + " | " + this.room + " | " + this.checkInDate + " | " + this.checkOutDate;
    }

    @Override
    public int compareTo(Reservation o) {
        return this.checkInDate.compareTo(o.checkInDate);
    }
}

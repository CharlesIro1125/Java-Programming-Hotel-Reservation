package model;

public enum RoomType {
    SINGLE_BED, DOUBLE_BED;
}

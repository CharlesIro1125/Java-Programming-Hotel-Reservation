package Menu;

import Service.CustomerService;
import api.HotelResource;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Date;
import java.util.List;

public class MainMenu {

    public MainMenu(){}

    public List<IRoom> find_rooms(Date checkInDate, Date checkOutDate){
        return HotelResource.findARoom(checkInDate,checkOutDate);

    }
    public Reservation reserve_room(String email,String firstname,String lastname,String roomNo,
                               Date checkInDate, Date checkOutDate){
        Reservation reservation = HotelResource.bookARoom(email,firstname,lastname,
                roomNo, checkInDate, checkOutDate);
        return reservation;

    }

    public List<Reservation> see_my_reservations(String email){
        return  HotelResource.getCustomersReservations(email);

    }

    public void create_account(String email,String firstname,String lastname){
        HotelResource.createACustomer(email,firstname,lastname);

    }

}

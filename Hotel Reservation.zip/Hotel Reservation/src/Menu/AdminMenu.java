package Menu;

import api.AdminResource;
import model.Customer;
import model.IRoom;
import model.RoomType;

import java.util.List;

public class AdminMenu {

    public AdminMenu(){}

    public List<Customer> see_all_customers(){
        return AdminResource.getAllCustomers();

    }

    public List<IRoom> see_all_rooms(){
        return AdminResource.getAllRooms();

    }

    public void see_all_reservations(){
        AdminResource.displayAllReservations();

    }
    public void add_room(String roomNo,Double roomPrice, RoomType roomType){
        AdminResource.addRooms(roomNo,roomPrice,roomType);
    }

}

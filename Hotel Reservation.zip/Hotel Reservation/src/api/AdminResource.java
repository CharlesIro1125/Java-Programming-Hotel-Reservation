package api;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;
import model.RoomType;

import java.util.List;

public final class AdminResource {

    private AdminResource(){}

    public static Customer getCustomer(String email){
        return CustomerService.getCustomer(email);
    }

    public static void addRooms(String roomNo,Double roomPrice, RoomType roomType){
        ReservationService.addRoom(roomNo,roomPrice,roomType);

    }

    public static List<IRoom> getAllRooms(){
        return ReservationService.getAllRooms();
    }

    public static List<Customer> getAllCustomers(){
        return CustomerService.getAllCustomers();
    }

    public static void displayAllReservations(){
        ReservationService.printAllReservation();
    }
}

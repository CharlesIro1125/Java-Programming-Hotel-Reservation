package api;

import Service.CustomerService;
import Service.ReservationService;
import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.Date;
import java.util.List;

public final class HotelResource {

    private HotelResource(){}


    public static Customer getCustomer(String email){
        return CustomerService.getCustomer(email);
    }

    public static void createACustomer(String email,String firstname,String lastname){
        CustomerService.addCustomer(email,firstname,lastname);
    }


    public static IRoom getRoom(String roomNumber){
        return  ReservationService.getARoom(roomNumber);
    }


    public static Reservation bookARoom(String email,String firstname,String lastname,String roomNo, Date checkInDate,Date checkOutDate){
        Customer customer = getCustomer(email);
        IRoom room = getRoom(roomNo);
        return ReservationService.reserveARoom(customer,room,checkInDate,checkOutDate);
    }


    public static List<Reservation> getCustomersReservations(String customerEmail){
        Customer customer = getCustomer(customerEmail);
        return ReservationService.getCustomersReservation(customer);
    }


    public static List<IRoom> findARoom(Date checkInDate,Date checkOutDate){
        return ReservationService.findRooms(checkInDate,checkOutDate);
    }

}
